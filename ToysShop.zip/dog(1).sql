drop database if exists dog;
create database dog;
use dog;
-- 用户表
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `password` varchar(255) DEFAULT '',
  `power`int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `user` values(1,'zhangsan','123',1);
insert into `user` values(2,'zhangsan1','123',1);
insert into `user` values(3,'zhangsan2','123',1);
insert into `user` values(4,'admin','admin',2);

-- 订单表
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  -- 订单代码
  `orderCode` varchar(255) NOT NULL DEFAULT '',
  -- 总金额
  `sum` double unsigned NOT NULL DEFAULT '0.00',
  -- 总数
  `totalNumber` int(11) unsigned NOT NULL DEFAULT '0',
  -- 地址
  `address` varchar(255) DEFAULT '',
  -- 发货人
  `post` varchar(255) DEFAULT '',
  -- 收货人
  `receiver` varchar(255) DEFAULT '',
  -- 联系方式
  `mobile` varchar(255) DEFAULT '',
  -- 用户消息
  `userMessage` varchar(255) DEFAULT '',
  -- 创建时间
  `createDate` datetime DEFAULT NULL,
  -- 支付时间
  `payDate` datetime DEFAULT NULL,
  -- 发货时间
  `deliverDate` datetime DEFAULT NULL,
  -- 完成时间
  `confirmDate` datetime DEFAULT NULL,
  -- 状态
  `status` varchar(255) DEFAULT NULL,

  PRIMARY KEY (`id`),
  KEY `fk_order_user` (`uid`),
  CONSTRAINT `fk_order_user` FOREIGN KEY (`uid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `order` values(1,1,'ABC',30.00,5,'岭南师范学院','AAA','zhangsan','18520439682','',sysdate(),'2019-12-30','2019-12-30','2019-12-30','已收货');


CREATE TABLE `user_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  -- 用户ID
  `uid` int(11) DEFAULT NULL,
  -- 余额
  `money` double NOT NULL DEFAULT '0.00',
  -- 地址
  `address` varchar(255) DEFAULT '',
  -- 联系方式
  `tel` varchar(50) DEFAULT '',
  -- 身份证
  `IDcard` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `fk_detail_user` (`uid`),
  CONSTRAINT `fk_detail_user` FOREIGN KEY (`uid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `user_detail` values(1,1,1000.00,'岭南师范学院','18520439222','440199911111111');
insert into `user_detail` values(2,2,1000.00,'岭南师范学院','18520439222','440199911111111');
insert into `user_detail` values(3,3,1000.00,'岭南师范学院','18520439222','440199911111111');
insert into `user_detail` values(4,4,0.00,'岭南师范学院','18520439222','440199911111111');

CREATE TABLE category (
  id int(11) NOT NULL AUTO_INCREMENT,
  -- 分类名称
  name varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


insert into category values(2,'步枪');
insert into category values(1,'私人飞机');

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  -- 分类ID
  `cid` int(11) DEFAULT NULL,
  -- 产品名称
  `name` varchar(255) NOT NULL DEFAULT '',
  -- 价格
  `nowPrice` double unsigned NOT NULL DEFAULT '0.00',
  -- 存货
  `stock` int(11) unsigned NOT NULL DEFAULT '0',
  -- 创建时间
  `createDate` datetime DEFAULT NULL,
  -- 评论数量
  `commentCount` int(11) unsigned NOT NULL DEFAULT '0',
  -- 销售数量
  `saleCount` int(11) unsigned NOT NULL DEFAULT '0',
  -- 商品图片
  imge varchar(255),
  PRIMARY KEY (`id`),
  KEY `fk_product_category` (`cid`),
  CONSTRAINT `fk_product_category` FOREIGN KEY (`cid`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `product` values(1,1,'私人飞机1',675678678.00,50,'2019-9-10',0,0,'/plane/1.jpg');
insert into `product` values(2,1,'私人飞机2',64534537788.50,50,'2019-9-10',0,0,'/plane/2.jpg');
insert into `product` values(3,1,'私人飞机3',64534537578.00,50,'2019-9-10',0,0,'/plane/3.jpg');
insert into `product` values(4,1,'私人飞机4',254378786783.00,50,'2019-9-10',0,0,'/plane/4.jpg');
insert into `product` values(5,1,'私人飞机5',275378378378.00,50,'2019-9-10',0,0,'/plane/5.jpg');
insert into `product` values(6,2,'步枪1',50006.00,50,'2019-9-10',0,0,'/gun/1.jpg');
insert into `product` values(7,2,'步枪2',62222.00,50,'2019-9-10',0,0,'/gun/2.jpg');
insert into `product` values(8,2,'步枪3',67866.00,50,'2019-9-10',0,0,'/gun/3.jpg');
insert into `product` values(9,2,'步枪4',68543.00,50,'2019-9-10',0,0,'/gun/4.jpg');
insert into `product` values(10,2,'步枪5',67867.00,50,'2019-9-10',0,0,'/gun/5.jpg');

CREATE TABLE `cartitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  -- 用户id
  `uid` int(11) DEFAULT NULL,
  -- 商品ID
  `pid` int(11) DEFAULT NULL,
  -- 数量
  `number` int(11) NOT NULL DEFAULT '0',
  -- 总金额
  `sum` double NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `fk_cartitem_product` (`pid`),
  KEY `fk_cartitem_user` (`uid`),
  CONSTRAINT `fk_cartitem_product` FOREIGN KEY (`pid`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_cartitem_user` FOREIGN KEY (`uid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into cartitem values(1,1,1,2,12.00);
insert into cartitem values(2,1,2,4,26.00);
insert into cartitem values(3,2,2,4,12.00);

CREATE TABLE `orderitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  -- 订单号
  `oid` int(11) DEFAULT NULL,
  -- 商品ID
  `pid` int(11) DEFAULT NULL,
  -- 数量
  `number` int(11) unsigned NOT NULL DEFAULT '0',
  -- 总金额
  `sum` double unsigned NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `fk_orderitem_product` (`pid`),
  KEY `fk_orderitem_order` (`oid`),
  CONSTRAINT `fk_orderitem_order` FOREIGN KEY (`oid`) REFERENCES `order` (`id`),
  CONSTRAINT `fk_orderitem_product` FOREIGN KEY (`pid`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `orderitem` values(1,1,1,2,12.00);
insert into `orderitem` values(2,1,3,3,18.00);

CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  -- 商品ID
  `pid` int(11) DEFAULT NULL,
  -- 评论用户ID
  `uid` int(11) DEFAULT NULL,
  -- 订单内容
  `otid` int(11) DEFAULT NULL,
  -- 评论内容
  `content` varchar(500) DEFAULT NULL,
  -- 创建时间
  `createDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comment_product` (`pid`),
  KEY `fk_comment_user` (`uid`),
  KEY `fk_comment_orderitem` (`otid`),
  CONSTRAINT `fk_comment_product` FOREIGN KEY (`pid`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_comment_user` FOREIGN KEY (`uid`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_comment_orderitem` FOREIGN KEY (`otid`) REFERENCES `orderitem` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


