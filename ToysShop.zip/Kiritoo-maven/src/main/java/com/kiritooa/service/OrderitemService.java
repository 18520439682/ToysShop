package com.kiritooa.service;

import java.util.List;

import com.kiritooa.pojo.Orderitem;

public interface OrderitemService {
	
	List<Orderitem> findOrderitemByOid(int oid);//根据订单号oid查找订单内容
	
	boolean insertOrderitem(Orderitem ot);//插入订单内容
	
	boolean deleteOrderitem(int oid);//删除订单内容
	
	List<Orderitem> findMessageByOid(int oid);//根据订单号查找订单内容(包含产品信息)
	
	int findOtidByOidAndPid(int oid,int pid);//根据订单编号和商品编号查找订单内容id
}
