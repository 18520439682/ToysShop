package com.kiritooa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiritooa.mapper.OrderitemMapper;
import com.kiritooa.pojo.Orderitem;
import com.kiritooa.pojo.OrderitemExample;
import com.kiritooa.pojo.OrderitemExample.Criteria;
import com.kiritooa.service.OrderitemService;
@Service
public class OrderitemServiceImpl implements OrderitemService {
	@Autowired
	private OrderitemMapper orderitemMapper;
	public List<Orderitem> findOrderitemByOid(int oid) {//根据订单号oid查找订单内容
		// TODO Auto-generated method stub
		OrderitemExample example = new OrderitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andOidEqualTo(oid);
		return orderitemMapper.selectByExample(example);
	}

	public boolean insertOrderitem(Orderitem ot) {//插入订单内容
		// TODO Auto-generated method stub
		boolean flag = false;
		if(orderitemMapper.insertSelective(ot) == 1){
			flag = true;
		}
		return flag;
	}

	public boolean deleteOrderitem(int oid) {//根据订单号oid删除订单内容
		// TODO Auto-generated method stub
		boolean flag = false;
		OrderitemExample example = new OrderitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andOidEqualTo(oid);
		if(orderitemMapper.deleteByExample(example) == 1){
			flag = true;
		}
		return flag;
	}

	public List<Orderitem> findMessageByOid(int oid) {
		// TODO Auto-generated method stub
		return orderitemMapper.findOrderitemByoid(oid);
	}

	public int findOtidByOidAndPid(int oid, int pid) {
		// TODO Auto-generated method stub
		OrderitemExample example = new OrderitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andOidEqualTo(oid);
		criteria.andPidEqualTo(pid);
		List<Orderitem> list = orderitemMapper.selectByExample(example);
		return list.get(0).getId();
	}
}
