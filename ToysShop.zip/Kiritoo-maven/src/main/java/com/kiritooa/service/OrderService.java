package com.kiritooa.service;

import java.util.List;

import com.kiritooa.pojo.Order;

public interface OrderService {
	
	List<Order> findAllOrder();//查找所有订单
	
	List<Order> findAllOrderByUid(int uid);//根据uid查找用户所有订单
	
	List<Order> findApplyReturnOrder();//查找退货审核中的所有订单
	
	List<Order> findUnpayOrder();//查找所有未支付订单
	
	boolean insertOrder(Order order);//插入订单
	
	boolean updateStatus(int id,String status);//根据用户uid修改订单状态
	
	boolean updatePay̬Date(int id);//修改支付时间
	
	int findIdByOrderCode(String orderCode);//根据订单编码查找订单号
	
	int updateSumAndTotalNumberById(int id,double sum,int total);//根据订单id修改订单商品总数量和商品总价格
	
	Order findOrderMessageByOid(int id);//根据订单id查找订单信息
	
	boolean updateUserMessagerByOid(int oid,String usermessage);//根据订单号插入退货理由
}
