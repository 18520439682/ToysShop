package com.kiritooa.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.kiritooa.mapper.CartitemMapper;
import com.kiritooa.mapper.ProductMapper;
import com.kiritooa.pojo.Cartitem;
import com.kiritooa.pojo.Product;
import com.kiritooa.pojo.ProductExample;
import com.kiritooa.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	
	
	
	@Autowired
	private ProductMapper productMapper;
	private ApplicationContext ac;
	
	public ApplicationContext getAc(){
		return new ClassPathXmlApplicationContext("applicationContext.xml");
	}
	
	@Override
	public List<Product> selectByExample(ProductExample example) {

		return productMapper.selectByExample(example);
	}

	@Override
	public int updateByPrimaryKey(Product record) {

		return productMapper.updateByPrimaryKey(record);
	}

	@Override
	public Product selectByPrimaryKey(Integer iId) {

		return productMapper.selectByPrimaryKey(iId);
	}

	@Override
	public int deleteByPrimaryKey(Integer iId) {
		return productMapper.deleteByPrimaryKey(iId);
	}
	

	@Override
	public List<Product> findAllProduct() {
		
		ac = new ProductServiceImpl().getAc();
		return productMapper.selectAll();
	}

	@Override
	public boolean insertProduct(Product p) {
		
		boolean flag = false;
		Date date=new Date();
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String d = format.format(date);
		Date createdate;
		try {
			createdate = format.parse(d);
			p.setCreatedate(createdate);
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		p.setCommentcount(0);
		p.setSalecount(0);
		if(productMapper.insertSelective(p) == 1){
			flag = true;
		}
		return flag;
	}
	
	
	public boolean updatePrice(int id, double newPrice) {//修改商品价格
		// TODO Auto-generated method stub
		ac = new ProductServiceImpl().getAc();
		boolean flag = false;
		Product p = new Product();
		p.setId(id);
		p.setNowprice(newPrice);
		if(productMapper.updateByPrimaryKeySelective(p) == 1){
			flag = true;
		}
		CartitemMapper cartitemMapper = (CartitemMapper) ac.getBean("cartitemMapper");
		Cartitem cartitem = new Cartitem();
		cartitem.setPid(id);
		cartitem.setSum(newPrice);
		//int a = 100/0;
		cartitemMapper.updateSum(cartitem);//同步更新购物车里的商品总价sum
		return flag;
	}


	public boolean updateStock(int id, int stock) {//修改商品库存
		// TODO Auto-generated method stub
		boolean flag = false;
		Product p = new Product();
		p.setId(id);
		p.setStock(stock);
		if(productMapper.updateByPrimaryKeySelective(p) == 1){
			flag = true;
		}
		return flag;
	}


	public boolean updateName(int id, String name) {//修改商品名称
		// TODO Auto-generated method stub
		boolean flag = false;
		Product p = new Product();
		p.setId(id);
		p.setName(name);
		if(productMapper.updateByPrimaryKeySelective(p) == 1){
			flag = true;
		}
		return flag;
	}


	public boolean updatesaleCount(int id, int saleCount) {//修改商品销售数量
		// TODO Auto-generated method stub
		boolean flag = false;
		Product p = new Product();
		p.setId(id);
		p.setSalecount(saleCount);
		if(productMapper.updateByPrimaryKeySelective(p) == 1){
			flag = true;
		}
		return flag;
	}


	public boolean updatecommentCount(int id, int commentCount) {//修改商品评论数量
		// TODO Auto-generated method stub
		boolean flag = false;
		Product p = new Product();
		p.setId(id);
		p.setCommentcount(commentCount);
		if(productMapper.updateByPrimaryKeySelective(p) == 1){
			flag = true;
		}
		return flag;
	}


	public boolean updateCid(int id, int cid) {//修改商品类别
		// TODO Auto-generated method stub
		boolean flag = false;
		Product p = new Product();
		p.setId(id);
		p.setCid(cid);
		if(productMapper.updateByPrimaryKeySelective(p) == 1){
			flag = true;
		}
		return flag;
	}


	public boolean deleteProduct(int id) {//删除商品
		// TODO Auto-generated method stub
		boolean flag = false;
		Product p = new Product();
		p.setId(id);
		if(productMapper.deleteByPrimaryKey(id) == 1){
			flag = true;
		}
		return flag;
	}

	public List<Product> findProductByName(String name) {//按照商品名称模糊查找商品
		// TODO Auto-generated method stub
		return productMapper.selectLikeByName(name);
	}
	
	public int findProductStockByPid(int pid) {
		// TODO Auto-generated method stub
		Product product = productMapper.selectByPrimaryKey(pid);
		return product.getStock();
	}
	public Product findMessagerByPid(int pid) {//按照商品编号查找商品信息
		// TODO Auto-generated method stub
		return productMapper.selectByPrimaryKey(pid);
	}

	@Override
	public double getSumByPidAndNum(int pid, int number) {//根据商品编号和数量计算总价格
		// TODO Auto-generated method stub
		double price = productMapper.getProductPirce(pid);
		return price * number;
	}

//	@Override
//	public boolean updatePrice(int id, double newPrice) {
//		
//		boolean flag = false;
//		Product p = new Product();
//		p.setId(id);
//		p.setNowprice(newPrice);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updateStock(int id, int stock) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setStock(stock);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updateName(int id, String name) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setName(name);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updatesaleCount(int id, int saleCount) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setSalecount(saleCount);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updatecommentCount(int id, int commentCount) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setCommentcount(commentCount);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updateCid(int id, int cid) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setCid(cid);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean deleteProduct(int id) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		if(productMapper.deleteByPrimaryKey(id) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public List<Product> findProductByName(String name) {
//		
//		return null;
//	}@Override
//	public boolean updatePrice(int id, double newPrice) {
//		
//		boolean flag = false;
//		Product p = new Product();
//		p.setId(id);
//		p.setNowprice(newPrice);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updateStock(int id, int stock) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setStock(stock);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updateName(int id, String name) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setName(name);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updatesaleCount(int id, int saleCount) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setSalecount(saleCount);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updatecommentCount(int id, int commentCount) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setCommentcount(commentCount);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean updateCid(int id, int cid) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		p.setCid(cid);
//		if(productMapper.updateByPrimaryKeySelective(p) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public boolean deleteProduct(int id) {
//		
//		boolean flag = false;
//		ac = new ProductServiceImpl().getAc();
//		Product p = (Product) ac.getBean("product");
//		p.setId(id);
//		if(productMapper.deleteByPrimaryKey(id) == 1){
//			flag = true;
//		}
//		return flag;
//	}
//
//	@Override
//	public List<Product> findProductByName(String name) {
//		
//		return null;
//	}



}
