package com.kiritooa.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.kiritooa.pojo.Cartitem;
import com.kiritooa.pojo.Order;
import com.kiritooa.pojo.Orderitem;
import com.kiritooa.pojo.Product;
import com.kiritooa.pojo.UserDetail;
import com.kiritooa.service.CartitemService;
import com.kiritooa.service.OrderService;
import com.kiritooa.service.OrderitemService;
import com.kiritooa.service.ProductService;
import com.kiritooa.service.PurchaseService;
import com.kiritooa.service.UserService;
import com.kiritooa.service.User_detailService;
import com.kiritooa.util.SnowFlake;
@Service
public class PurchaseServiceImpl implements PurchaseService {
	@Autowired
	private CartitemService cartitemService;
	@Autowired
	private OrderService orderService;
	@Autowired
	private ProductService productService;
	@Autowired
	private OrderitemService orderitemService;
	@Autowired
	private User_detailService user_detailService;
	@Autowired
	private UserService userService;
	

	public int commitOrder(int uid,int arr[],Order order) {//提交订单(前台传来的order里面只带有address，receiver，mobile，userMessage)
		// TODO Auto-generated method stub
		System.out.println(order);
		int flag = 0;
		//生成订单
		SnowFlake snowFlake = new SnowFlake(1,1);
		//System.out.println(snowFlake.getSnowFlake());
		String xuehua = snowFlake.getSnowFlake();//调用雪花函数产生一个ordercode
		Date date = new Date();
		order.setUid(uid);
		order.setOrdercode(xuehua);
		order.setCreatedate(date);//设置订单创建日期为系统当前时间
		order.setStatus("未支付");
		//计算总数量
		if(orderService.insertOrder(order)){//判断订单是否已生成
			List<Cartitem> list = cartitemService.findCartitemMessagerByUid(uid);//获取用户购物车信息
			int id = orderService.findIdByOrderCode(xuehua);//获取刚刚生成订单的id
			int totalNumber = 0;
			double sum = 0;
			for (Cartitem cartitem : list) {
				for (int pid : arr) {
					if(cartitem.getPid() == pid){//判断该商品是否在购物车中已勾选
						totalNumber = totalNumber + cartitem.getNumber();//计算总数量
						sum = sum + (cartitem.getNumber() * cartitem.getProduct().getNowprice());//计算总价     该物品的总价 = 购买数量 * 单价
						Orderitem ot = new Orderitem();
						ot.setOid(id);
						ot.setPid(pid);
						ot.setNumber(cartitem.getNumber());
						ot.setSum(cartitem.getSum());
						orderitemService.insertOrderitem(ot);//将购物车中已勾选的插入订单内容
						int stock = cartitem.getProduct().getStock();//获取商品当前库存
						stock = stock - cartitem.getNumber();//计算新库存 = 当前库存 - 购物车中该商品的数量
						productService.updateStock(pid, stock);//修改库存
						//修改库存
						cartitemService.deleteByUidAndPid(uid, pid);//删除该用户购物车中该商品记录
					}
				}
			}
			orderService.updateSumAndTotalNumberById(id, sum, totalNumber);//修改订单商品总数量和订单总价格				
			flag = id;
		}
		return flag;
	}


	public boolean payOrder(int id) {//支付订单
		// TODO Auto-generated method stub
		boolean flag = false;
		Order order = orderService.findOrderMessageByOid(id);
		UserDetail ud = user_detailService.findUser_detailByUid(order.getUid());
		double money = ud.getMoney() - order.getSum();
		if(money >= 0){//判断账户余额是否够支付
			user_detailService.updateMoney(order.getUid(), money);//修改用户余额
			//user_detailService.updateMoney(uid, money);
			UserDetail ud2 = user_detailService.findUser_detailByUid(userService.findAdmin());//查找管理员账户余额
			double money2 = ud2.getMoney() + order.getSum();
			user_detailService.updateMoney(userService.findAdmin(), money2);//修改管理账户余额
			orderService.updateStatus(id, "待发货");//修改订单状态
			orderService.updatePay̬Date(id);//修改支付时间
			List<Orderitem> list = orderitemService.findOrderitemByOid(id);
			for (Orderitem orderitem : list) {//循环订单内容
				Product product = productService.findMessagerByPid(orderitem.getPid());
				int saleCount = product.getSalecount() + orderitem.getNumber();
				productService.updatesaleCount(orderitem.getPid(), saleCount);//修改商品销售数量
			}
			flag = true;
		}
		return flag;
	}


/*	public boolean applyCancelOrder(int id) {//申请取消订单
		// TODO Auto-generated method stub
		boolean flag = false;
		//修改订单状态为取消中
		if(orderService.updateStatus(id, "取消中")){
			flag = true;
		}
		return flag;
	}*/


	public boolean cancelOrder(int id) {//取消订单
		// TODO Auto-generated method stub
		boolean flag = false;
		/*Order order = orderService.findOrderMessageByOid(id);//查找该订单信息
		UserDetail ud = user_detailService.findUser_detailByUid(order.getUid());//查找该用户信息
		double money = ud.getMoney() + order.getSum();
		user_detailService.updateMoney(order.getUid(), money);//退还用户金额
		
		UserDetail ud2 = user_detailService.findUser_detailByUid(userService.findAdmin());//查找管理员账户余额
		double money2 = ud2.getMoney() - order.getSum();
		user_detailService.updateMoney(userService.findAdmin(), money2);*/
		
		orderService.updateStatus(id, "已取消");//将订单状态改为已取消
		
		List<Orderitem> list = orderitemService.findOrderitemByOid(id);//按照订单查找订单内容
		for (Orderitem orderitem : list) {//循环订单内容
			int newStock = productService.findProductStockByPid(orderitem.getPid()) + orderitem.getNumber();//计算返还商品后的库存
			productService.updateStock(orderitem.getPid(), newStock);//修改库存
		}
		flag = true;
		return flag;
	}


	public boolean applyReturned(int id) {//用户申请退货
		// TODO Auto-generated method stub
		return orderService.updateStatus(id, "退货审核中");
	}


	public boolean returndeOrder(int id) {//管理员同意退货
		// TODO Auto-generated method stub
		boolean flag = false;
		Order order = orderService.findOrderMessageByOid(id);//查找该订单信息
		UserDetail ud = user_detailService.findUser_detailByUid(order.getUid());//查找该用户信息
		double money = ud.getMoney() + order.getSum();
		user_detailService.updateMoney(order.getUid(), money);//退还用户金额
		
		UserDetail ud2 = user_detailService.findUser_detailByUid(userService.findAdmin());//查找管理员账户余额
		double money2 = ud2.getMoney() - order.getSum();
		user_detailService.updateMoney(userService.findAdmin(), money2);
		
		orderService.updateStatus(id, "已退货");//将订单状态改为已取消
		
		List<Orderitem> list = orderitemService.findOrderitemByOid(id);//按照订单查找订单内容
		for (Orderitem orderitem : list) {//循环订单内容
			int newStock = productService.findProductStockByPid(orderitem.getPid()) + orderitem.getNumber();//计算返还商品后的库存
			productService.updateStock(orderitem.getPid(), newStock);//修改库存
		}
		flag = true;
		return flag;
	}


	public boolean confirmOrder(int id) {//用户确认收货
		// TODO Auto-generated method stub
		return orderService.updateStatus(id, "已确认");
		
	}


	public boolean disReturnOrder(int id) {//商家不同意退货
		// TODO Auto-generated method stub
		return orderService.updateStatus(id, "拒绝退货");
	}
}
