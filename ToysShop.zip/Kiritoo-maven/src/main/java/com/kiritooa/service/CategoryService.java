package com.kiritooa.service;

import java.util.List;

import com.kiritooa.pojo.Category;
import com.kiritooa.pojo.CategoryExample;


public interface CategoryService {

	int insertCategory(Category category);

	List<Category> selectByExample(CategoryExample example);

	int updateByPrimaryKey(Category record);

	Category selectByPrimaryKey(Integer id);

	int deleteByPrimaryKey(Integer id);
	
	List<Category> findAllCategory();

}
