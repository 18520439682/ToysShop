package com.kiritooa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiritooa.mapper.CategoryMapper;
import com.kiritooa.pojo.Category;
import com.kiritooa.pojo.CategoryExample;
import com.kiritooa.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
	private CategoryMapper categoryMapper;
	
	@Override
	public int insertCategory(Category category) {
		return categoryMapper.insert(category);
		
	}
	
	@Override
	public List<Category> selectByExample(CategoryExample example){
		return categoryMapper.selectByExample(example);
		
	}

	@Override
	public int updateByPrimaryKey(Category record) {

		return categoryMapper.updateByPrimaryKey(record);
	}

	@Override
	public Category selectByPrimaryKey(Integer id) {

		return categoryMapper.selectByPrimaryKey(id);
	}
	
	@Override
	public int deleteByPrimaryKey(Integer id) {
		return categoryMapper.deleteByPrimaryKey(id);
	}

	@Override
	public List<Category> findAllCategory() {
		// TODO Auto-generated method stub
		return categoryMapper.findAllCategory();
	}

}
