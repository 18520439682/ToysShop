package com.kiritooa.service;

import java.util.List;

import com.kiritooa.pojo.Comment;

public interface CommentService {
	List<Comment> findCommentByPidAndUid(int uid,int pid);//根据用户uid和商品pid查找评论
	
	boolean insertComment(Comment comment);//插入评论
	
	List<Comment> findCommentByPid(int pid);//根据商品pid查找评论
}
