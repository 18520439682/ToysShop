package com.kiritooa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiritooa.mapper.UserMapper;
import com.kiritooa.pojo.ProductExample;
import com.kiritooa.pojo.User;
import com.kiritooa.pojo.UserExample;
import com.kiritooa.pojo.UserExample.Criteria;
import com.kiritooa.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper userMapper;

	@Override
	public User selectByPrimaryKey(Integer id) {

		return userMapper.selectByPrimaryKey(id);
	}

	
	public User checkLogin(String username,String password) {
		System.out.println(username+","+password);
		User user = userMapper.findByUsername(username);
		System.out.println(user);
		if (user != null && user.getPassword().equals(password)) {
			return user;
		}else {
			User u = new User();
			u.setPower(0);
			return u;
		}
		

	}

	@Override
	public int register(User user) {
		return userMapper.insert(user);
	}
	
	@Override
	public List<User> selectAllUser(UserExample example){
		return userMapper.selectByExample(example);
		
	}
	
	public int saveUser(User u) {
		return userMapper.updateByPrimaryKey(u);
	}
	

	public boolean logintest(String username, String password) {
		boolean flag = false;
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andNameEqualTo(username);
		criteria.andPasswordEqualTo(password);
		List<User> select = userMapper.selectByExample(example);
		if (select.isEmpty()) {
			flag = false;
		} else {
			flag = true;
		}
		return flag;
	}
	
	public List<User> findUserByNameAndPassword(String name, String password) {
		// TODO Auto-generated method stub
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andNameEqualTo(name);
		criteria.andPasswordEqualTo(password);
		List<User> list = userMapper.selectByExample(example);
		return list;
	}
	public User findUserMessage(int id) {
		// TODO Auto-generated method stub
		return userMapper.findUserMessagerByUid(id);
	}
	public int findAdmin() {
		// TODO Auto-generated method stub
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andPowerEqualTo(2);
		List<User> list = userMapper.selectByExample(example);
		return list.get(0).getId();
	}
	public boolean findUserByNameAndPw(String name, String password) {
		// TODO Auto-generated method stub
		boolean flag = false;
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andNameEqualTo(name);
		criteria.andPasswordEqualTo(password);
		List<User> list = userMapper.selectByExample(example);
		if(list.get(0).getPower() == 2){
			flag = true;
		}
		return flag;	
	}

}
