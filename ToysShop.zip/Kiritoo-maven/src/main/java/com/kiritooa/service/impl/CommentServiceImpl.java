package com.kiritooa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiritooa.mapper.CommentMapper;
import com.kiritooa.pojo.Comment;
import com.kiritooa.pojo.CommentExample;
import com.kiritooa.pojo.CommentExample.Criteria;
import com.kiritooa.pojo.Product;
import com.kiritooa.service.CommentService;
import com.kiritooa.service.ProductService;
@Service
public class CommentServiceImpl implements CommentService {
	@Autowired
	private CommentMapper commentMapper;
	@Autowired
	private ProductService productService;
	
	public List<Comment> findCommentByPidAndUid(int uid, int pid) {//根据用户uid和商品pid查找评论
		// TODO Auto-generated method stub
		CommentExample example = new CommentExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		criteria.andPidEqualTo(pid);
		return commentMapper.selectByExample(example);
	}

	public boolean insertComment(Comment comment) {//插入评论
		// TODO Auto-generated method stub
		boolean flag = false;
		if(commentMapper.insertSelective(comment) == 1){//插入评论
			Product product = productService.findMessagerByPid(comment.getPid());
			productService.updatecommentCount(comment.getPid(), product.getCommentcount()+1);//修改商品评论数量+1
			flag = true;
		}
		return flag;
	}

	public List<Comment> findCommentByPid(int pid) {//根据商品pid查找评论
		// TODO Auto-generated method stub
		CommentExample example = new CommentExample();
		Criteria criteria = example.createCriteria();
		criteria.andPidEqualTo(pid);
		return commentMapper.selectByExample(example);
	}

}
