package com.kiritooa.service;

import java.util.List;

import com.kiritooa.pojo.Product;
import com.kiritooa.pojo.ProductExample;


public interface ProductService {
	
    List<Product> selectByExample(ProductExample example);
    
    int updateByPrimaryKey(Product record);
    
    Product selectByPrimaryKey(Integer iId);
    
    int deleteByPrimaryKey(Integer iId);

	
	

	
    List<Product> findAllProduct();//查找所有商品
	
	boolean insertProduct(Product p);//插入商品
	
	boolean updatePrice(int id,double newPrice);//修改商品价格
	
	boolean updateStock(int id,int stock);//修改商品库存
	
	boolean updateName(int id,String name);//修改商品名称
	
	boolean updatesaleCount(int id,int saleCount);//修改商品销售数量
	
	boolean updatecommentCount(int id,int commentCount);//修改商品评论数量
	
	boolean updateCid(int id,int cid);//修改商品类别
	
	boolean deleteProduct(int id);//删除商品
	
	List<Product> findProductByName(String name);//按照商品名称模糊查找商品
	
	int findProductStockByPid(int pid);//按照商品编号查找商品库存
	
	Product findMessagerByPid(int pid);//按照商品编号查找该商品信息
	
	double getSumByPidAndNum(int pid,int number);//根据商品编号和数量计算总价格
}
