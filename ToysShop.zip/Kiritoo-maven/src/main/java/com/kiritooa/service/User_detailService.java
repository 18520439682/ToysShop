package com.kiritooa.service;

import com.kiritooa.pojo.UserDetail;

public interface User_detailService {
	boolean updateMoney(int uid,double money);//根据用户id和修改用户余额
	
	UserDetail findUser_detailByUid(int uid);//根据用户id查找用户信息
	
	boolean updateUser_detail(UserDetail userdetail);//修改用户信息
}
