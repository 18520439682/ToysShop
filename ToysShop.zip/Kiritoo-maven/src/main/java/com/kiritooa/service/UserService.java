package com.kiritooa.service;

import java.util.List;

import com.kiritooa.pojo.User;
import com.kiritooa.pojo.UserExample;



public interface UserService {

	List<User> selectAllUser(UserExample example);
	
	User selectByPrimaryKey(Integer id);
	
    User checkLogin(String name,String password);

    int saveUser(User u);
    
    
    int register(User user);
    
    boolean logintest(String name,String password);
    
    
    
	User findUserMessage(int id);
	
	int findAdmin();
	
	List<User> findUserByNameAndPassword(String name,String password);
	
	boolean findUserByNameAndPw(String name,String password);
    
}
