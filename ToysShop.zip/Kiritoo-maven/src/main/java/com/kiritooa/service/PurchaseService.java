package com.kiritooa.service;

import com.kiritooa.pojo.Order;


public interface PurchaseService {
	
	int commitOrder(int uid,int arr[],Order order);//提交订单,返回订单id
	
	boolean payOrder(int id);//支付订单
	
	//boolean applyCancelOrder(int id);//申请取消订单
	
	boolean cancelOrder(int id);//商家同意取消订单
	
	boolean applyReturned(int id);//用户申请退货
	
	boolean returndeOrder(int id);//商家同意退货
	
	boolean disReturnOrder(int id);//商家不同意退货
	
	boolean confirmOrder(int id);//用户确认收货
}
