package com.kiritooa.service;

import java.util.List;

import com.kiritooa.pojo.Cartitem;

public interface CartitemService {
	
	void displayCartitemByUid(int uid);//根据用户uid显示购物车
	
	List<Cartitem> findCartitemByUid(int uid);//根据用户uid返回用户购物车
	
	Cartitem findCartitemByUidAndPid(int uid,int pid);//根据用户uid和商品pid查找购物车记录
	
	int insertCartitem(Cartitem ct);//向购物车插入记录
	
	int updateNumberAddOne(Cartitem ct);//修改购物车商品+1
	
	int updateNumberRedOne(Cartitem ct);
	
	boolean deleteByUid(int uid);//根据用户uid清空
	
	boolean deleteByUidAndPid(int uid,int pid);//根据用户uid和pid清空购物车
	
	boolean updateSumOnUpdateProductPrice(int pid,double newPrice);//在商品更新时同步购物车总价
	
	List<Cartitem> findCartitemMessagerByUid(int uid);
	
	double getCartitemSum(int uid);//根据用户uid获取用户购物车总价格
	
	double getCartitemSumByUidAndPid(int uid,int pid);//根据用户uid和商品pid查找购物车中该商品总价
	
	int getCartitemBuySumByUid(int uid);//根据用户uid查找用户当前购物车商品总数
	
	int getCartitemBuySumByUidAndPid(int uid,int[] pid);//根据用户uid和商品编号pid返回商品购买总数
	
	List<Cartitem> findCartitemByUidAndPid(int uid,int[] pid);//根据用户选取的商品和用户id返回一个用户选取结账的商品数组
}
