package com.kiritooa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiritooa.mapper.UserDetailMapper;
import com.kiritooa.pojo.UserDetail;
import com.kiritooa.pojo.UserDetailExample;
import com.kiritooa.pojo.UserDetailExample.Criteria;
import com.kiritooa.service.User_detailService;
@Service
public class User_detailServiceImpl implements User_detailService {
	@Autowired
	private UserDetailMapper userDetailMapper;

	public boolean updateMoney(int uid, double money) {
		// TODO Auto-generated method stub
		boolean flag = false;
		UserDetailExample example = new UserDetailExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		UserDetail ud = new UserDetail();
		ud.setMoney(money);
		if(userDetailMapper.updateByExampleSelective(ud, example) == 1){
			flag = true;
		}
		return flag;
	}

	public UserDetail findUser_detailByUid(int uid) {
		// TODO Auto-generated method stub
		UserDetailExample example = new UserDetailExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		List<UserDetail> list = userDetailMapper.selectByExample(example);
		UserDetail userDetail = list.get(0);
		return userDetail;
	}

	public boolean updateUser_detail(UserDetail userdetail) {
		// TODO Auto-generated method stub
		boolean flag = false;
		UserDetailExample example = new UserDetailExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(userdetail.getUid());
		UserDetail ud = new UserDetail();
		ud.setAddress(userdetail.getAddress());
		ud.setIdcard(userdetail.getIdcard());
		ud.setTel(userdetail.getTel());
		if(userDetailMapper.updateByExampleSelective(ud, example) == 1){
			flag = true;
		}
		return flag;
		
	}

}
