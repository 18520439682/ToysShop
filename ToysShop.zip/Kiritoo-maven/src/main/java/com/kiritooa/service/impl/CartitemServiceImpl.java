package com.kiritooa.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiritooa.mapper.CartitemMapper;
import com.kiritooa.mapper.ProductMapper;
import com.kiritooa.pojo.Cartitem;
import com.kiritooa.pojo.CartitemExample;
import com.kiritooa.pojo.CartitemExample.Criteria;
import com.kiritooa.pojo.Product;
import com.kiritooa.service.CartitemService;
@Service
public class CartitemServiceImpl implements CartitemService {
	@Autowired
	private CartitemMapper cartitemMapper;
	@Autowired
	private ProductMapper productMapper;
	public void displayCartitemByUid(int uid) {
		// TODO Auto-generated method stub
		CartitemExample example = new CartitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		List<Cartitem> selectAll = cartitemMapper.selectByExample(example);
		for (Cartitem cartitem : selectAll) {
			System.out.println(cartitem);
		}
	}
	
	public List<Cartitem> findCartitemByUid(int uid){//根据用户uid查找用户购物车
		// TODO Auto-generated method stub
		CartitemExample example = new CartitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		return cartitemMapper.selectByExample(example);
	}
	
	public Cartitem findCartitemByUidAndPid(int uid,int pid) {//根据用户uid和商品pid查找购物车记录
		Cartitem cart = new Cartitem();
		cart.setUid(uid);
		cart.setPid(pid);
		return cartitemMapper.selectByUidAndPid(cart);
	}

	public int insertCartitem(Cartitem ct) {//向购物车中添加商品
		// TODO Auto-generated method stub
		int flag = 0;
		CartitemExample example = new CartitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(ct.getUid());
		List<Cartitem> selectAll = cartitemMapper.selectByExample(example);;//查找用户购物车
		for (Cartitem cartitem : selectAll) {//循环购物车
			if(ct.getPid() == cartitem.getPid()){//判断购物车中是否已存在该商品
				//如果商品已在购物车
				ct.setId(cartitem.getId());//设置修改的商品的pid
				ct.setNumber(cartitem.getNumber()+ct.getNumber());
				ct.setSum(cartitem.getSum()+ct.getSum());
				cartitemMapper.updateByPrimaryKeySelective(ct);//修改购物车该商品数量
				return flag = 1;
			}
		}
		flag = cartitemMapper.insert(ct);//执行插入
		return flag;
	}
	
	public int updateNumberAddOne(Cartitem ct){//购物车商品数量+1
		//System.out.println(ct.getPid());
		Product product = new Product();
		product = productMapper.selectByPrimaryKey(ct.getPid());//获取商品当前单价*/
		//System.out.println(product.getStock());
		if(product.getStock() == ct.getNumber()){//购物车里该商品的数量已经达到库存
			return 0;
		}else{
			Cartitem cartitem = new Cartitem();
			cartitem.setNumber(ct.getNumber() +1 );//设置数量+1
			cartitem.setSum(cartitem.getNumber() * product.getNowprice());//设置总价 = (+1后的数量) * (商品当前单价)
			CartitemExample example = new CartitemExample();
			Criteria criteria = example.createCriteria();
			criteria.andPidEqualTo(ct.getPid());
			criteria.andUidEqualTo(ct.getUid());
			return cartitemMapper.updateByExampleSelective(cartitem, example);//调用修改方法
		}
	}
	
	public int updateNumberRedOne(Cartitem ct){//购物车商品数量-1
		if(ct.getNumber() == 1){
			return 0;
		}else{
			Product product = productMapper.selectByPrimaryKey(ct.getPid());//获取商品当前单价
			Cartitem cartitem = new Cartitem();
			cartitem.setNumber(ct.getNumber() - 1);//设置数量-1
			cartitem.setSum(cartitem.getNumber() * product.getNowprice());//设置总价 = (-1后的数量) * (商品当前单价)
			CartitemExample example = new CartitemExample();
			Criteria criteria = example.createCriteria();
			criteria.andPidEqualTo(ct.getPid());
			criteria.andUidEqualTo(ct.getUid());
			return cartitemMapper.updateByExampleSelective(cartitem, example);//ִ调用修改方法
		}
	}

	public boolean deleteByUid(int uid) {//根据用户uid清空购物车
		// TODO Auto-generated method stub
		boolean flag = false;
		CartitemExample example = new CartitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		if(cartitemMapper.deleteByExample(example) == 1){
			flag = true;
		}
		return flag;
	}

	public boolean deleteByUidAndPid(int uid,int pid) {//根据用户uid和pid清空购物车
		// TODO Auto-generated method stub
		boolean flag = false;
		CartitemExample example = new CartitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		criteria.andPidEqualTo(pid);
		if(cartitemMapper.deleteByExample(example) == 1){
			flag = true;
		}
		return flag;
	}
	
	public boolean updateSumOnUpdateProductPrice(int pid,double newPrice){//在商品更新时同步购物车总价
		boolean flag = false;
		Cartitem cartitem = new Cartitem();
		cartitem.setPid(pid);
		cartitem.setSum(newPrice);
		cartitemMapper.updateSum(cartitem);
		return flag;
	}
	
	public List<Cartitem> findCartitemMessagerByUid(int uid){
		return cartitemMapper.findMessagerByUid(uid);
	}
	
	public double getCartitemSum(int uid){//根据用户uid获取用户购物车总价格
		List<Cartitem> list = cartitemMapper.findMessagerByUid(uid);
		double sum = 0.00;
		double i = 0.00;
		for (Cartitem cartitem : list) {
			i = cartitem.getNumber() * cartitem.getProduct().getNowprice();
			sum = sum + i;
		}
		return sum;
	}

	public double getCartitemSumByUidAndPid(int uid, int pid) {//根据用户uid和商品pid查找购物车中该商品总价
		// TODO Auto-generated method stub
		CartitemExample example = new CartitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		criteria.andPidEqualTo(pid);
		List<Cartitem> list = cartitemMapper.selectByExample(example);
		if(list.isEmpty()){
			return 0.00;
		}
		return list.get(0).getSum();
	}

	@Override
	public int getCartitemBuySumByUid(int uid) {//根据用户uid查找用户当前购物车商品总数
		// TODO Auto-generated method stub
		CartitemExample example = new CartitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		List<Cartitem> list = cartitemMapper.selectByExample(example);
		if(list.isEmpty()) {
			return 0;
		}else {
			int sum = 0;
			for (Cartitem cartitem : list) {
				sum = sum + cartitem.getNumber();
			}
			return sum;
		}
	}

	@Override
	public int getCartitemBuySumByUidAndPid(int uid, int[] arr) {//根据用户uid和商品编号pid返回商品购买总数
		// TODO Auto-generated method stub
		CartitemExample example = new CartitemExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		List<Cartitem> list = cartitemMapper.selectByExample(example);
		int number = 0;
		for (Cartitem cartitem : list) {
			for (int pid : arr) {
				if(cartitem.getPid() == pid) {
					number = number + cartitem.getNumber();//计算购物总数
				}
			}
		}
		return number;
	}

	@Override
	public List<Cartitem> findCartitemByUidAndPid(int uid, int[] arr) {//根据用户选取的商品和用户id返回一个用户选取结账的商品数组
		// TODO Auto-generated method stub
		List<Cartitem> list2 = new ArrayList<Cartitem>();
		List<Cartitem> list = cartitemMapper.findMessagerByUid(uid);
		for (Cartitem cartitem : list) {
			for (int pid : arr) {
				if(pid == cartitem.getPid()) {
					list2.add(cartitem);
				}
			}
		}
		return list2;
	}
}
