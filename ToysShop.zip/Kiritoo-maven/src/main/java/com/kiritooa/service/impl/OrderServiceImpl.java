package com.kiritooa.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiritooa.mapper.OrderMapper;
import com.kiritooa.pojo.Order;
import com.kiritooa.pojo.OrderExample;
import com.kiritooa.pojo.OrderExample.Criteria;
import com.kiritooa.service.OrderService;
@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderMapper orderMapper;

	public List<Order> findAllOrder() {//查找所有订单
		// TODO Auto-generated method stub
		return orderMapper.selectAll();
	}


	public List<Order> findAllOrderByUid(int uid) {//根据用户uid查找用户所有订单
		// TODO Auto-generated method stub
		OrderExample example = new OrderExample();
		Criteria criteria = example.createCriteria();
		criteria.andUidEqualTo(uid);
		return orderMapper.selectByExample(example);
	}


	public boolean insertOrder(Order order) {//插入订单
		// TODO Auto-generated method stub
		boolean flag = false;
		if(orderMapper.insertSelective(order) == 1){
			flag = true;
		}
		return flag;
	}


	public boolean updateStatus(int id, String status) {//根据用户uid更改订单状态̬
		// TODO Auto-generated method stub
		boolean flag = false;
		Order order = new Order();
		order.setId(id);
		order.setStatus(status);
		if(orderMapper.updateByPrimaryKeySelective(order) == 1){
			flag = true;
		}
		return flag;
	}
	
	public int findIdByOrderCode(String orderCode){//根据订单编码查找订单号
		OrderExample example = new OrderExample(); 
		Criteria criteria = example.createCriteria();
		criteria.andOrdercodeEqualTo(orderCode);
		List<Order> list = orderMapper.selectByExample(example);
		return list.get(0).getId();
	}
	
	public int updateSumAndTotalNumberById(int id,double sum,int total){//根据订单id修改订单商品总数量和商品总价格
		Order order = new Order();
		order.setId(id);
		order.setSum(sum);
		order.setTotalnumber(total);
		return orderMapper.updateByPrimaryKeySelective(order);
	}
	
	public Order findOrderMessageByOid(int id){
		return orderMapper.selectByPrimaryKey(id);
	}


	public List<Order> findApplyReturnOrder() {
		// TODO Auto-generated method stub
		OrderExample example = new OrderExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusEqualTo("退货审核中");
		return orderMapper.selectByExample(example);
	}


	public List<Order> findUnpayOrder() {
		// TODO Auto-generated method stub
		OrderExample example = new OrderExample();
		Criteria criteria = example.createCriteria();
		criteria.andStatusEqualTo("未支付");
		return orderMapper.selectByExample(example);
	}


	public boolean updatePay̬Date(int id) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Order order = new Order();
		order.setId(id);
		Date date = new Date();
		order.setPaydate(date);
		if(orderMapper.updateByPrimaryKeySelective(order) == 1){
			flag = true;
		}
		return flag;
	}


	public boolean updateUserMessagerByOid(int oid, String usermessage) {//根据订单号插入退货理由
		// TODO Auto-generated method stub
		boolean flag = false;
		Order order = new Order();
		order.setId(oid);
		order.setUsermessage(usermessage);
		if(orderMapper.updateByPrimaryKeySelective(order) == 1){
			flag = true;
		}
		return flag;
	}

}
