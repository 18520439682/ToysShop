package com.kiritooa.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kiritooa.mapper.ProductMapper;
import com.kiritooa.pojo.Cartitem;
import com.kiritooa.pojo.CartitemExample;
import com.kiritooa.pojo.CartitemExample.Criteria;
import com.kiritooa.pojo.Product;
import com.kiritooa.service.CartitemService;
import com.kiritooa.service.impl.CartitemServiceImpl;



public class CartitemTest {
	public ApplicationContext getAc(){
		return new ClassPathXmlApplicationContext("applicationContext.xml");	
	}
	public static void main(String[] args) {
		ApplicationContext ac = new CartitemTest().getAc();
		CartitemService bean = (CartitemService) ac.getBean("cartitemServiceImpl");	
		
		/*CartitemService p = new CartitemServiceImpl();
		p.updateSumOnUpdateProductPrice(1,2);*/
		
		//bean.displayCartitemByUid(2);
		
		Cartitem ct = new Cartitem();
		ct.setUid(1);
		ct.setPid(3);
		ct.setNumber(10);
		ct.setSum(65.00);
		System.out.println(bean.insertCartitem(ct));
		
		/*Cartitem ct = (Cartitem) ac.getBean("cartitem");
		ct.setPid(1);
		ct.setUid(1);
		ct.setNumber(3);
		ct.setSum(12.00);
		System.out.println(bean.updateNumberRedOne(ct));*/
		
	 //	System.out.println(bean.deleteCartitem(3));
		
		//System.out.println(bean.deleteByPid(4, 2));
		
		
		//商品加一
		/*Cartitem ct = new Cartitem();
		ct.setUid(1);
		ct.setPid(1);
		ct.setNumber(4);
		System.out.println(bean.updateNumberAddOne(ct));*/
		
		/*List<Cartitem> list = bean.findCartitemMessagerByUid(1);
		for (Cartitem cartitem : list) {
			System.out.println(cartitem);
			System.out.println(cartitem.getProduct().getNowprice());
		}*/
	}
}
