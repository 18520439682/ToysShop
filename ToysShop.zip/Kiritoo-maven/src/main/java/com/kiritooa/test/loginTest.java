package com.kiritooa.test;


import com.kiritooa.service.UserService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class loginTest {


    public ApplicationContext getAc() {
        return new ClassPathXmlApplicationContext("applicationContext.xml");
    }
    
   
    
    public static void main(String[] args) {
    	ApplicationContext ac = new loginTest().getAc();
  	  	UserService bean = (UserService) ac.getBean("userServiceImpl");
  	  	System.out.println(bean.logintest("2017764523", "123456"));
    }
}