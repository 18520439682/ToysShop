package com.kiritooa.coms;

public class Commons {
	public static final String pic ="http://localhost:8083/FileService";

}
