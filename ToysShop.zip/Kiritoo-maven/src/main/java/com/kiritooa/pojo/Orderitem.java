package com.kiritooa.pojo;

import org.springframework.stereotype.Component;

@Component
public class Orderitem {
    private Integer id;

    private Integer oid;

    private Integer pid;

    private Integer number;

    private Double sum;
    
    private Product product;

    public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOid() {
        return oid;
    }

    public void setOid(Integer oid) {
        this.oid = oid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Double getSum() {
        return sum;
    }

    public void setSum(Double sum) {
        this.sum = sum;
    }

	@Override
	public String toString() {
		return "Orderitem [id=" + id + ", oid=" + oid + ", pid=" + pid
				+ ", number=" + number + ", sum=" + sum + "]";
	}
    
}