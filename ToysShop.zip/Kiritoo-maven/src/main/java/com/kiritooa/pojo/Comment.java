package com.kiritooa.pojo;

import java.util.Date;

public class Comment {
    private Integer id;

    private Integer pid;

    private Integer uid;

    private Integer otid;

    private String content;

    private Date createdate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getOtid() {
        return otid;
    }

    public void setOtid(Integer otid) {
        this.otid = otid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

	@Override
	public String toString() {
		return "Comment [id=" + id + ", pid=" + pid + ", uid=" + uid
				+ ", otid=" + otid + ", content=" + content + ", createdate="
				+ createdate + "]";
	}
    
}