package com.kiritooa.pojo;

public class UserDetail {
    private Integer id;

    private Integer uid;

    private Double money;

    private String address;

    private String tel;

    private String idcard;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Double getMoney() {
        return money;
    }

    public void setMoney(Double money) {
        this.money = money;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard == null ? null : idcard.trim();
    }

	@Override
	public String toString() {
		return "UserDetail [id=" + id + ", uid=" + uid + ", money=" + money
				+ ", address=" + address + ", tel=" + tel + ", idcard="
				+ idcard + "]";
	}
    
}