package com.kiritooa.pojo;

import java.util.Date;

public class Product {
    private Integer id;

    private Integer cid;

    private String name;

    private Double nowprice;

    private Integer stock;

    private Date createdate;

    private Integer commentcount;

    private Integer salecount;

    private String imge;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Double getNowprice() {
        return nowprice;
    }

    public void setNowprice(Double nowprice) {
        this.nowprice = nowprice;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getCommentcount() {
        return commentcount;
    }

    public void setCommentcount(Integer commentcount) {
        this.commentcount = commentcount;
    }

    public Integer getSalecount() {
        return salecount;
    }

    public void setSalecount(Integer salecount) {
        this.salecount = salecount;
    }

    public String getImge() {
        return imge;
    }

    public void setImge(String imge) {
        this.imge = imge == null ? null : imge.trim();
    }

	@Override
	public String toString() {
		return "Product [id=" + id + ", cid=" + cid + ", name=" + name
				+ ", nowprice=" + nowprice + ", stock=" + stock
				+ ", createdate=" + createdate + ", commentcount="
				+ commentcount + ", salecount=" + salecount + ", imge=" + imge
				+ "]";
	}
    
}