package com.kiritooa.pojo;

import org.springframework.stereotype.Component;

@Component
public class Cartitem {
    private Integer id;

    private Integer uid;

    private Integer pid;

    private Integer number;

    private Double sum;
    
    private Product product;
    
    
    public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Double getSum() {
        return sum;
    }

    public void setSum(Double sum) {
        this.sum = sum;
    }

	@Override
	public String toString() {
		return "Cartitem [id=" + id + ", uid=" + uid + ", pid=" + pid
				+ ", number=" + number + ", sum=" + sum + "]";
	}
    
}