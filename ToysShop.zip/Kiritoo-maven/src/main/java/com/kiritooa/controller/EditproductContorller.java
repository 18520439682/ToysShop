package com.kiritooa.controller;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;


import com.kiritooa.coms.Commons;
import com.kiritooa.pojo.Product;
import com.kiritooa.pojo.ProductExample;
import com.kiritooa.service.ProductService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;


@Controller
public class EditproductContorller {
	
	@Autowired
	private ProductService productService;
	

	//编辑
	@RequestMapping("/edit")
	public String edit(Model m,int id){
		Product product = productService.selectByPrimaryKey(id);
	    m.addAttribute("product", product);
		return "index";
	}
	
	//保存
	@RequestMapping("saveOrUpdate")
	public String saveOrUpdate(Product m) {
		productService.updateByPrimaryKey(m);
		return"redirect:listAdmin.do";
	}


	@RequestMapping("uploadPic")
	public void uploadPic(HttpServletRequest request,String fileName,PrintWriter out){
		//把Request强转成多部件请求对象
		MultipartHttpServletRequest mh = (MultipartHttpServletRequest) request;
		//根据文件名称获取文件对象
		CommonsMultipartFile cm = (CommonsMultipartFile) mh.getFile(fileName);
		//获取文件上传流
		byte[] fbytes = cm.getBytes();
		
		//文件名称在服务器有可能重复？
		String newFileName="";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		newFileName = sdf.format(new Date());
		
		Random r = new Random();
		
		for(int i =0 ;i<3;i++){
			newFileName=newFileName+r.nextInt(10);
		}
		
		//获取文件扩展名
		String originalFilename = cm.getOriginalFilename();
		String suffix = originalFilename.substring(originalFilename.lastIndexOf("."));
		
		//创建jesy服务器，进行跨服务器上传
		Client client = Client.create();
		//把文件关联到远程服务器
		WebResource resource = client.resource(Commons.pic+"/upload/"+newFileName+suffix);
		//上传
		resource.put(String.class, fbytes);
		
		
		//ajax回调函数需要会写写什么东西？
		//图片需要回显：需要图片完整路径
		//数据库保存图片的相对路径.
		String fullPath = Commons.pic+"/upload/"+newFileName+suffix;
		
		String relativePath="/upload/"+newFileName+suffix;
		//{"":"","":""}
		String result="{\"fullPath\":\""+fullPath+"\",\"relativePath\":\""+relativePath+"\"}";
		
		out.print(result);
				
		
	}
}
