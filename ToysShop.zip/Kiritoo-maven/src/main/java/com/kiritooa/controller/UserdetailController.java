package com.kiritooa.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kiritooa.pojo.UserDetail;
import com.kiritooa.service.User_detailService;

@Controller
public class UserdetailController {
	@Autowired
	private User_detailService uds;
	
	
	@RequestMapping("finduserdetail")
	public String finduserdetail(int uid,Model m){//查找用户信息
		UserDetail ud = uds.findUser_detailByUid(uid);
		m.addAttribute("u_d", ud);
		return "userdetail";
	}
	
	@RequestMapping("update")
	public String update_userdetail(int uid,Model m){//跳转到修改用户信息
		UserDetail ud = uds.findUser_detailByUid(uid);//查找用户信息
		m.addAttribute("u_d", ud);
		return "updateud";
	}
	
	@RequestMapping("updateUserdetail")
	public String update(UserDetail ud,Model m,HttpSession session){//修改用户信息
		int uid = (Integer) session.getAttribute("uid");
		ud.setUid(uid);
		uds.updateUser_detail(ud);
		UserDetail ud1 = uds.findUser_detailByUid(uid);
		m.addAttribute("u_d", ud1);
		return"userdetail";
	}
	
	@RequestMapping("toRecharge")
	public String toRecharge(int uid,Model m){//跳转到充值界面
		UserDetail userdetail = uds.findUser_detailByUid(uid);
		m.addAttribute("u_d",userdetail);
		return "Recharge";
	}
	
	@RequestMapping("Recharge")
	public String Recharge(Model m,double money,HttpSession session){//充值
		int uid = (Integer) session.getAttribute("uid");
		UserDetail detail = uds.findUser_detailByUid(uid);
		double sum = detail.getMoney() + money;
		uds.updateMoney(uid, sum);//修改余额
		UserDetail ud = uds.findUser_detailByUid(uid);
		m.addAttribute("u_detail", ud);
		return "home";
	}
}
