package com.kiritooa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kiritooa.pojo.Cartitem;
import com.kiritooa.pojo.Product;
import com.kiritooa.pojo.ProductExample;
import com.kiritooa.pojo.User;
import com.kiritooa.pojo.UserDetail;
import com.kiritooa.pojo.UserExample;
import com.kiritooa.service.CartitemService;
import com.kiritooa.service.ProductService;
import com.kiritooa.service.UserService;
import com.kiritooa.service.User_detailService;

//这里用了@SessionAttributes，可以直接把model中的user(也就key)放入其中
//这样保证了session中存在user这个对象
//@RequestMapping("/user")根目录加多一层路径/user
@Controller
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private CartitemService cartitemService;

	@Autowired
	private ProductService productService;

	@Autowired
	private User_detailService uds;

	@RequestMapping("/index")
	public String index() {
		return "index";
	}

	@RequestMapping("/login.do")
//    @RequestMapping(value="login.action")
//    @RequestMapping(value="login.action",method=requestMethod.GET)
	public String login() {
		return "login";//
	}

	// 表单提交过来的路径
	@RequestMapping(value = "/checkLogin.do", method = RequestMethod.POST)
	public String checkLogin(User user, Model model, HttpSession session) {
		if (userService.findUserByNameAndPassword(user.getName(), user.getPassword()).isEmpty()) {
			return "error";
		} else {
			// 调用service方法
			user = userService.checkLogin(user.getName(), user.getPassword());
			System.out.println(user.getPower());
			if (user.getPower() == 2) {
				session.setAttribute("uid", user.getId());
				UserDetail detail = uds.findUser_detailByUid(user.getId());
				session.setAttribute("u_detail", detail);
				session.setAttribute("user", user);
				model.addAttribute("user", user);
				return "redirect:toadmin.do";
			} else {
				session.setAttribute("uid", user.getId());
				UserDetail detail = uds.findUser_detailByUid(user.getId());
				session.setAttribute("u_detail", detail);
				session.setAttribute("user", user);
				model.addAttribute("user", user);
				return "redirect:tohome.do";
			}
		}

	}

	@RequestMapping("tohome")
	public String tohome(Model model, HttpSession session) {
		ProductExample example = new ProductExample();
		List<Product> list = productService.selectByExample(example);
		model.addAttribute("productLsit", list);
		
		
		int uid = (int) session.getAttribute("uid");
		List<Cartitem> cartList = cartitemService.findCartitemMessagerByUid(uid);
		double sum = cartitemService.getCartitemSum(uid);
		model.addAttribute("sum",sum);
		session.setAttribute("cartitem", cartList);
		return "home";
	}
	
	@RequestMapping("toshop")
	public String toshop(Model model, HttpSession session) {
		ProductExample example = new ProductExample();
		List<Product> list = productService.selectByExample(example);
		model.addAttribute("productLsit", list);
		return "shop";
	}
	
	

	@RequestMapping("/error.do")
	public String error() {
		return "fail";
	}

	// 注销方法
	@RequestMapping("/outLogin.do")
	public String outLogin(HttpSession session) {

		session.invalidate();
		return "login";
	}

	@RequestMapping("/register.do")
	public String regist() {
		return "register";
	}

	@RequestMapping("/updateuser.do")
	public String updateUser(Model m, int id) {
		System.out.println(id);
		User user = userService.selectByPrimaryKey(id);
		m.addAttribute("user", user);
		return "updateuser";
	}

	@RequestMapping("/saveuser")
	public String saveOrUpdate(User u) {
		System.out.println(u);
		userService.saveUser(u);
		return "redirect:alluser.do";
	}

//	@RequestMapping("/doRegister.do")
//	public String doRegist(@RequestParam("name") String username, @RequestParam("password") String password) {
//		if{userService.selectAllUser(example)}
//		User user = new User();
//		user.setName(username);
//		user.setPassword(password);
//		user.setPower(1);
//		userService.register(user);
//		return "doRegister";
//	}

	@RequestMapping("/alluser.do")
	public String allUser(Model model, HttpSession session) {
		UserExample example = new UserExample();
		List<User> list = userService.selectAllUser(example);
		for (User user : list) {
			System.out.println(user);
		}
		model.addAttribute("userList", list);
		return "alluser";
	}

}