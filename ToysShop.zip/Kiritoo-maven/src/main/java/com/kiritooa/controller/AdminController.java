package com.kiritooa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kiritooa.pojo.Order;
import com.kiritooa.service.OrderService;
import com.kiritooa.service.PurchaseService;
import com.kiritooa.service.UserService;

@Controller
public class AdminController {
	@Autowired
	private UserService userService;
	@Autowired
	private OrderService orderService;
	@Autowired
	private PurchaseService ps;
	
	@RequestMapping("bgindex")
	public String tobgindex(){
		return "bgindex";
	}
	
	@RequestMapping("bglogin")
	public String tobghome(String name,String password){
		if(userService.findUserByNameAndPw(name, password)){
			return"bghome";
		}else{
			return "";
		}
	}
	
	@RequestMapping("toManagerReturn")
	public String tomanager(Model m){
		List<Order> list = orderService.findApplyReturnOrder();
		List<Order> list2 = orderService.findUnpayOrder();
		m.addAttribute("order2", list2);//未支付订单
		m.addAttribute("order", list);//申请退货的订单
		return "managerorder";
	}
	
	@RequestMapping("agreecancel")
	public String argeecancel(int oid,Model m){//同意退货
		ps.returndeOrder(oid);
		List<Order> list = orderService.findApplyReturnOrder();
		m.addAttribute("order", list);
		return "managerorder";
	}
	
	@RequestMapping("disagreecancel")
	public String disagreecancel(int oid,Model m){//商家不同意退货
		ps.disReturnOrder(oid);
		List<Order> list = orderService.findApplyReturnOrder();
		m.addAttribute("order", list);
		return "managerorder";
	}
	
	@RequestMapping("cancel1")
	public String cancelOrder(Model m,int oid){//管理员取消订单
		ps.cancelOrder(oid);//取消订单
		List<Order> list = orderService.findApplyReturnOrder();
		List<Order> list2 = orderService.findUnpayOrder();
		m.addAttribute("order2", list2);//未支付订单
		m.addAttribute("order", list);//申请退货的订单
		return "managerorder";
	}
}
