package com.kiritooa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kiritooa.pojo.Category;
import com.kiritooa.pojo.CategoryExample;
import com.kiritooa.service.CategoryService;

public class CategoryContorller {
	
	@Autowired
	private CategoryService categoryService;


    @RequestMapping("/insertCategory")
    public void insert(Category category){
    	
    	categoryService.insertCategory(category);
    }
    @RequestMapping("/deleteCategory")
    public void delete(int id){
    	categoryService.deleteByPrimaryKey(id);
    }
    @RequestMapping("/updateCategory")
    public void update(Category category){
    	categoryService.updateByPrimaryKey(category);
    }
    @RequestMapping("/selectCategory")
    public Category select(int id){
        return categoryService.selectByPrimaryKey(id);
    }
    
    @RequestMapping("/selectAllCategory")
    public List<Category> selectAll(Model model){
    	CategoryExample example = new CategoryExample();
        return categoryService.selectByExample(example);
    }

}
