package com.kiritooa.controller;

import java.util.List;
















import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kiritooa.pojo.Cartitem;
import com.kiritooa.pojo.Order;
import com.kiritooa.pojo.Orderitem;
import com.kiritooa.pojo.UserDetail;
import com.kiritooa.service.CartitemService;
import com.kiritooa.service.OrderService;
import com.kiritooa.service.OrderitemService;
import com.kiritooa.service.PurchaseService;
import com.kiritooa.service.User_detailService;

@Controller
public class OrderController {
	@Autowired
	private PurchaseService ps;
	@Autowired
	private OrderService orderService;
	@Autowired
	private User_detailService uds;
	@Autowired
	private CartitemService cartitemService;
	@Autowired
	private OrderitemService orderitemService;
	
	
	@RequestMapping("tocommit")
	public String tocommit(int uid,int[] allpid,Model m,HttpSession session){
		session.setAttribute("allpid", allpid);//将前端传来的结算pid数组设置为会话属性
		List<Cartitem> list = cartitemService.findCartitemByUidAndPid(uid, allpid);
//		System.out.println("1111111111111111111111111");
//		for (Cartitem cartitem : list) {
//			System.out.println(cartitem.getProduct().getName());
//		}
		double sum = 0;
		for (Cartitem cartitem : list) {
			sum = sum + cartitem.getSum();
		}
		m.addAttribute("buysum", sum);
		m.addAttribute("buylist", list);
		return "ordercommit";
	}
	
	@RequestMapping("commit")
	public String commit(Order order,Model m,HttpSession session){
		int[] arr = (int[]) session.getAttribute("allpid");
		int uid = (Integer) session.getAttribute("uid");
		int oid = ps.commitOrder(uid, arr, order);//调用生成订单方法
		m.addAttribute("oid", oid);
		return "commited";
	} 
	
	@RequestMapping("toordermanager")
	public String toordermanager(Model m,HttpSession session){
		int uid = (Integer) session.getAttribute("uid");
		List<Order> list = orderService.findAllOrderByUid(uid);
		m.addAttribute("order", list);
		return "ordermanager";
	}
	
	@RequestMapping("pay")
	public String pay(int oid,HttpSession session){//支付订单
		if(ps.payOrder(oid)){
			int uid = (Integer) session.getAttribute("uid");
			UserDetail detail = uds.findUser_detailByUid(uid);
			session.setAttribute("u_detail", detail);
			return "paid";
		}
		return "";
	}
	
	@RequestMapping("cancelOrder")
	public String cancelOrder(Model m,int oid,int uid){//用户取消订单
		ps.cancelOrder(oid);
		List<Order> list = orderService.findAllOrderByUid(uid);
		m.addAttribute("order", list);
		return "ordermanager";
	}
	
	@RequestMapping("toapplyCancelOrder")
	public String toapplyCancel(Model m,int oid,HttpSession session){//跳转至填写退货理由界面
		session.setAttribute("o_id", oid);
		List<Orderitem> list = orderitemService.findMessageByOid(oid);
		m.addAttribute("orderitem", list);
		return "applycancelorder";
	}
	
	@RequestMapping("applyReturnOrder")
	public String cancelOrder(Model m,String usermessage,HttpSession session){//申请退货
		int o_id = (Integer) session.getAttribute("o_id");
		int uid = (Integer) session.getAttribute("uid");
		orderService.updateUserMessagerByOid(o_id, usermessage);//插入退货理由
		ps.applyReturned(o_id);//修改为退货审核状态
		List<Order> list = orderService.findAllOrderByUid(uid);
		m.addAttribute("order", list);
		return "ordermanager";
	}
	
	@RequestMapping("confirm")
	public String confirm(int oid,int uid,Model m){
		ps.confirmOrder(oid);
		List<Order> list = orderService.findAllOrderByUid(uid);
		m.addAttribute("order", list);
		return "ordermanager";
	}
}
