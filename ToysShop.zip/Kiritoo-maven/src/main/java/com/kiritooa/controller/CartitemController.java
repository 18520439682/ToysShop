package com.kiritooa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kiritooa.pojo.Cartitem;
import com.kiritooa.service.CartitemService;
import com.kiritooa.service.ProductService;

@Controller
public class CartitemController {
	@Autowired
	private CartitemService cartitemService;
	@Autowired
	private ProductService productService;
	
	//加入购物车
	@RequestMapping("/addCartitem")
	public String toCartitem(int id,int number,
			HttpSession session,Model m) {
		int uid = (int) session.getAttribute("uid");
		System.out.println(number+","+uid+","+id);
		Cartitem cart = new Cartitem();
		cart.setUid(uid);
		cart.setPid(id);
		cart.setNumber(number);
		double sum = productService.getSumByPidAndNum(id, number);
		cart.setSum(sum);
		System.out.println(sum);
		cartitemService.insertCartitem(cart);
		List<Cartitem> list = cartitemService.findCartitemMessagerByUid(uid);
		double SUM = cartitemService.getCartitemSum(uid);
		m.addAttribute("sum",SUM);
		session.setAttribute("cartitem", list);
		return "cartitem";
	}
	
	
	@RequestMapping("toCartitem")
	public String toCartitem(int uid,HttpSession session,Model m){
		List<Cartitem> list = cartitemService.findCartitemMessagerByUid(uid);
		int number = cartitemService.getCartitemBuySumByUid(uid);
		m.addAttribute("buysum",number);
		double sum = cartitemService.getCartitemSum(uid);
		m.addAttribute("sum",sum);
		session.setAttribute("cartitem", list);
		return "cartitem";
	}
	
	
	
	@RequestMapping("add")
	public @ResponseBody Cartitem addCartitem(@RequestBody Cartitem cartitem,int[] arr,HttpSession session){
		cartitemService.updateNumberAddOne(cartitem);//执行购物车该商品加1
		Cartitem c = cartitemService.findCartitemByUidAndPid(cartitem.getUid(),cartitem.getPid());//查找该商品增加后的数量
		double sum = 0;
		int uid = (Integer) session.getAttribute("uid");
		for (int pid : arr) {
			 sum =  sum + cartitemService.getCartitemSumByUidAndPid(uid, pid);
		}
		//double sum = cartitemService.getCartitemSum(cartitem.getUid());//获取购物车总价
		c.setSum(sum);
		return c;
	}
	
	@RequestMapping("red")
	public @ResponseBody Cartitem redCartitem(@RequestBody Cartitem cartitem,int[] arr,HttpSession session){
		cartitemService.updateNumberRedOne(cartitem);//执行购物车该商品减1
		//查找该商品增加后的数量
		Cartitem c = cartitemService.findCartitemByUidAndPid(cartitem.getUid(),cartitem.getPid());//查找该商品增加后的数量
		double sum = 0;
		int uid = (Integer) session.getAttribute("uid");
		for (int pid : arr) {
			 sum =  sum + cartitemService.getCartitemSumByUidAndPid(uid, pid);
		}
		//double sum = cartitemService.getCartitemSum(cartitem.getUid());//获取购物车总价
		c.setSum(sum);
		return c;
	}
	
	@RequestMapping("sum")
	public @ResponseBody Cartitem sum(@RequestBody Cartitem cartitem){//计算购物车全选后的总价
		double sum = cartitemService.getCartitemSum(cartitem.getUid());
		Cartitem ct = new Cartitem();
		ct.setSum(sum);
		return ct;
	}
	
	@RequestMapping("checksum")
	public @ResponseBody Cartitem checksum(@RequestBody Cartitem cartitem){
		double sum = cartitemService.getCartitemSumByUidAndPid(cartitem.getUid(), cartitem.getPid());
		Cartitem ct = new Cartitem();
		ct.setSum(sum);;
		return ct;
	}
	
	@RequestMapping("del")
	public @ResponseBody Cartitem del(@RequestBody Cartitem cartitem,int[] arr,HttpSession session){
		int uid = (Integer) session.getAttribute("uid");
		cartitemService.deleteByUidAndPid(uid, cartitem.getPid());//删除购物车中该商品
		double sum = 0;
		for (int pid : arr) {
			sum = sum + cartitemService.getCartitemSumByUidAndPid(uid, pid);
		}
		cartitem.setSum(sum);
		return cartitem;
	}
	
	@RequestMapping("Calculationsum")
	public @ResponseBody Cartitem getsum(@RequestBody Cartitem cartitem){//在点击加减商品数量时计算购物车总价格
		double sum = cartitemService.getCartitemSum(cartitem.getUid());
		cartitem.setSum(sum);
		return cartitem;
	}
	
	@RequestMapping("Calculationbuysum")
	public @ResponseBody Cartitem getBuySum(@RequestBody Cartitem cartitem) {//全选时计算购物车商品总数量
		int number = cartitemService.getCartitemBuySumByUid(cartitem.getUid());
		cartitem.setNumber(number);
		return cartitem;
	}
	
	@RequestMapping("CheckBuySum")
	public @ResponseBody Cartitem getCheckBuySum(@RequestBody Cartitem cartitem,int[] allpid) {//修改checkbox时计算选中的商品总数量
		int number = cartitemService.getCartitemBuySumByUidAndPid(cartitem.getUid(), allpid);
		cartitem.setNumber(number);
		return cartitem;
	}
}
