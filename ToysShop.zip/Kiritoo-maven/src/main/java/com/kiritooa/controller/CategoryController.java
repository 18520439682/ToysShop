package com.kiritooa.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kiritooa.pojo.Category;
import com.kiritooa.service.CategoryService;

@Controller
public class CategoryController {
	@Autowired
	private CategoryService cs;
	
	@RequestMapping("tocategory")
	public String tocategory(HttpSession session) {
		List<Category> list = cs.findAllCategory();
		session.setAttribute("category", list);
		return"category";
	}
	
	
}
