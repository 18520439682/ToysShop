package com.kiritooa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kiritooa.pojo.Cartitem;
import com.kiritooa.pojo.Category;
import com.kiritooa.pojo.CategoryExample;
import com.kiritooa.pojo.Product;
import com.kiritooa.pojo.ProductExample;
import com.kiritooa.pojo.User;
import com.kiritooa.service.CategoryService;
import com.kiritooa.service.ProductService;



@Controller
public class ProductContorller {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private CategoryService categoryService;
	
	@RequestMapping("/toAddPro")
	public String toProductAdd(Model model) {
		CategoryExample example = new CategoryExample();
		List<Category> list = categoryService.selectByExample(example);
		for (Category category : list) {
			System.out.println(category.getName());
		}
		model.addAttribute("categoryList",list);
		return "toAddPro";
	}
	
	@RequestMapping("/addproduct")
	public String productAdd(Product p,HttpServletRequest request) {
		Product pro = new Product();
		String category=request.getParameter("category");
		System.out.println(category+"类别");
		pro.setName(p.getName());
		pro.setNowprice(p.getNowprice());
		pro.setStock(p.getStock());
		pro.setImge(p.getImge());
		productService.insertProduct(pro);
		return "redirect:listproduct.do";
	}
	
//	@RequestMapping("/listUser")
//	public String productList(Model model,HttpSession session) {
//
//		ProductExample example = new ProductExample();
//		List<Product> list = productService.selectByExample(example);
//		model.addAttribute("productLsit",list);
//		return "product";
//	}
//
//	@RequestMapping("/listAdmin")
//	public String hello(Model model,HttpSession session){
//
//		ProductExample example = new ProductExample();
//		List<Product> list = productService.selectByExample(example);
//		model.addAttribute("productLsit",list);
//		return "admin/productAdmin";
//	}
	
	
	@RequestMapping("/toadmin")
	public String editProduct(Model model,HttpSession session){

		ProductExample example = new ProductExample();
		List<Product> list = productService.selectByExample(example);
		model.addAttribute("productLsit",list);
		return "admin/editProduct";
	}

	@RequestMapping("/listproduct")
	public String listproduct(Model model,HttpSession session){
		ProductExample example = new ProductExample();
		List<Product> list = productService.selectByExample(example);
		for (Product product : list) {
			System.out.println(product.getName());
		}
		model.addAttribute("productLsit",list);
		return "admin/productAdmin";
	}
	
	//商品详细信息
	@RequestMapping("/detail")
	public String productDetail(Model model,int id,int uid) {
		Product product = productService.selectByPrimaryKey(id);
	    model.addAttribute("product", product);
	    model.addAttribute("uid",uid);
		return "productdetail";
	}
	

	
	

}
