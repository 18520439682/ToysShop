package com.kiritooa.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kiritooa.pojo.Comment;
import com.kiritooa.pojo.Orderitem;
import com.kiritooa.pojo.Product;
import com.kiritooa.service.CommentService;
import com.kiritooa.service.OrderitemService;
import com.kiritooa.service.ProductService;

@Controller
public class CommentController {
	@Autowired
	private OrderitemService orderitemService;
	@Autowired
	private CommentService commentService;
	@Autowired
	private ProductService productService;
	
	//private static int userid;
	//private static int o_id;
	//private static int p_id;
	
	@RequestMapping("findTobeCommented")
	public String findTobeCommented(int uid,int oid,Model m,HttpSession session){//查找待评论
		List<Orderitem> list = orderitemService.findMessageByOid(oid);
		m.addAttribute("uid",uid);
		m.addAttribute("list", list);
		session.setAttribute("o_id2", oid);
		//o_id = oid;
		//userid = uid;
		return "tobecomment";
	}
	
	@RequestMapping("commentornot")
	public @ResponseBody Comment commentornot(@RequestBody Comment comment,HttpSession session){//判断是否已经评论
		List<Comment> list = commentService.findCommentByPidAndUid(comment.getUid(), comment.getPid());
		session.setAttribute("p_id", comment.getPid());
		//userid = comment.getUid();
		if(list.isEmpty()){
			comment.setId(0);
			return comment;
		}
		comment = list.get(0);
		return comment;
	}
	
	@RequestMapping("tocomment")
	public String tocomment(Model m,HttpSession session){//跳转到评论界面
		int p_id = (Integer) session.getAttribute("p_id");
		Product product = productService.findMessagerByPid(p_id);
		m.addAttribute("product", product);
		return "comment";
	}
	
	@RequestMapping("comment")
	public String comment(Model m,String content,HttpSession session){//评论
		int p_id = (Integer) session.getAttribute("p_id");
		int uid = (Integer) session.getAttribute("uid");
		int o_id = (Integer) session.getAttribute("o_id2");
		//System.out.println(p_id+","+uid);
		Comment comment = new Comment();
		comment.setContent(content);
		Date date = new Date();
		comment.setCreatedate(date);
		comment.setPid(p_id);
		comment.setUid(uid);
		int otid = orderitemService.findOtidByOidAndPid(o_id, p_id);
		comment.setOtid(otid);
		commentService.insertComment(comment);//插入评论
		List<Orderitem> list = orderitemService.findMessageByOid(o_id);//更新数组
		m.addAttribute("uid",uid);
		m.addAttribute("list", list);
		return "tobecomment";
	}
}
