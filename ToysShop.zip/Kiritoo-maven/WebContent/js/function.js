  document.write("<script type='text/javascript' src='js/jquery.js'></script>"); 

	function json1(a,uid,pid,index){
		var number = $(a).val();//获取数量
		var oCheck = document.getElementsByName('check');
  		var arr = new Array();
  		for(var i=0;i<oCheck.length;i++){
			if(oCheck[i].checked){
				arr.push(oCheck[i].value);
			}
		}
		var json = JSON.stringify({"uid":uid,"pid":pid,"number":number});//封装成json格式
		$.ajax({
			type:'POST',/* 请求类型为post */
			 url:'${pageContext.request.contextPath}/cartitemController/red.do?arr='+arr,/* 请求路径      ?time=new Date() */
			 contentType: 'application/json;charset=UTF-8',/* 向服务器提出的请求类型text */
			 dataType: 'json',
			 data:json,/* 请求的数据 */
			  success: function(data){/* 回调函数 */
				  var b = eval(data);
			  	  if(number == b.number){
			  		  alert("亲,数量不能为0!");
			  	  }else{
			  		  var oCheck = document.getElementsByName('check');
			  		  
			  		$(a).val(b.number);
			  		 if(oCheck[index].checked){
				  		$("#sum").val(b.sum);
			  		 }
			  	  }
			  }
		});
	}
	function json2(a,uid,pid,index){
		var number = $(a).val();//获取数量
		var oCheck = document.getElementsByName('check');
  		var arr = new Array();
  		for(var i=0;i<oCheck.length;i++){
			if(oCheck[i].checked){
				arr.push(oCheck[i].value);
			}
		}
		var json = JSON.stringify({"uid":uid,"pid":pid,"number":number});//封装成json格式
		$.ajax({
			type:'POST',/* 请求类型为post */
			 url:'${pageContext.request.contextPath}/cartitemController/add.do?arr='+arr,/* 请求路径      ?time=new Date() */
			 contentType: 'application/json;charset=UTF-8',/* 向服务器提出的请求类型text */
			 dataType: 'json',
			 data:json,/* 请求的数据 */
			  success: function(data){/* 回调函数 */
				  var b = eval(data);
			  	  if(number == b.number){
			  		  alert("亲,库存不足!");
			  	  }else{
			  		
			  		$(a).val(b.number);
			  		 if(oCheck[index].checked){
				  		$("#sum").val(b.sum);
			  		 }
			  	  }
			  }
		});
	}
	
	function deleteRow(r,pid){
		if(confirm('您确定将该商品从购物车中移除?')){
			var i = r.parentNode.parentNode.rowIndex;
			document.getElementById('myTable').deleteRow(i);
			json3(pid);//调用删除商品函数
		}
	}
	
	function json3(pid){//删除商品
		var oCheck = document.getElementsByName('check');
  		var arr = new Array();
  		for(var i=0;i<oCheck.length;i++){
			if(oCheck[i].checked){
				arr.push(oCheck[i].value);
			}
		}
  		var json = JSON.stringify({"pid":pid});
  		$.ajax({
  			type:'POST',
  			url:'${pageContext.request.contextPath}/cartitemController/del.do?arr='+arr,
  			contentType: 'application/json;charset=UTF-8',
  			dataType: 'json',
  			data:json,
  			success: function(data){
  				var b = eval(data);
  				$("#sum").val(b.sum);
  			}
  		})
	}
	
	function allcheck(uid){//全选
		var oCheck = document.getElementsByName('check');
		for(var i=0;i<oCheck.length;i++){
			oCheck[i].checked = true;
		}
		var json = JSON.stringify({"uid":uid});
		$.ajax({
			type:'POST',
			url:'${pageContext.request.contextPath}/cartitemController/sum.do',
			contentType: 'application/json;charset=UTF-8',
			dataType: 'json',
			data:json,
			success: function(data){
				var b = eval(data);
				$("#sum").val(b.sum);
			}
		})
	}
	
	function Settlement(){
		var flag = false;
		var allpid = new Array();
		var oCheck = document.getElementsByName('check');
		for(var i=0;i<oCheck.length;i++){
			if(oCheck[i].checked){
				allpid.push(oCheck[i].value);
				flag = true;
			}
		}
		if(flag){
			location.href="${pageContext.request.contextPath}/orderController/tocommit.do?uid=${uid}&allpid="+allpid;
		}else{
			alert("您至少选择一个商品，才能进行结算");
		}
	}
	
	function checksum(index,uid,pid){
		var sum = 0;
		var json = JSON.stringify({"uid":uid,"pid":pid});
		var oCheck = document.getElementsByName('check');
		$.ajax({
			type:'POST',
			url:'${pageContext.request.contextPath}/cartitemController/checksum.do',
			contentType: 'application/json;charset=UTF-8',
			dataType: 'json',
			data:json,
			success: function(data){
				var b = eval(data);
				sum = b.sum;
				if(oCheck[index].checked){
					var i = parseFloat($("#sum").val()) + parseFloat(sum);
					$("#sum").val(i);
				}else{
					var k = parseFloat($("#sum").val()) - parseFloat(sum);
					$("#sum").val(k);
				}
			}
		})	
	}
	
	function controlLen(){
	    //获取input输入框元素
	    var inputText = document.getElementById('mytext').value;
	    if(inputText.length > 240){
	        var text = inputText.substring(0,240);
	        document.getElementById('mytext').value = text;//重新设置input输入框的值
	        alert("最多输入200个字");
	    }
	}
	
	function tocomment(pid,uid){
		var json = JSON.stringify({"uid":uid,"pid":pid});//封装成json格式
		$.ajax({
			type:'POST',/* 请求类型为post */
			 url:'${pageContext.request.contextPath}/commentController/commentornot.do',/* 请求路径      ?time=new Date() */
			 contentType: 'application/json;charset=UTF-8',/* 向服务器提出的请求类型text */
			 dataType: 'json',
			 data:json,/* 请求的数据 */
			  success: function(data){/* 回调函数 */
				  var b = eval(data);
			  	  if(b.id == 0){
			  		  location.href="${pageContext.request.contextPath}/commentController/tocomment.do";
			  	  }else{
			  		alert('您已经评论了该商品!');
			  	  }
			  }
		});
	}